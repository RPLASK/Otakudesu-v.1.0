<?php
	include('layout/head.php');
	include('layout/sidebar.php');
	include('layout/navbar.php');
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_title">
					<h2>Edit Akun</h2>
					<div class="pull-right">
                        <div class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
							<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
							<script type='text/javascript'>
							<!--
							  var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
							  var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
							  var date = new Date();
							  var day = date.getDate();
							  var month = date.getMonth();
							  var thisDay = date.getDay(),thisDay = myDays[thisDay];
							  var yy = date.getYear();
							  var year = (yy < 1000) ? yy + 1900 : yy;
							  document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
							-->
							</script>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<?php 
				include "koneksi.php";
				$id 	= $_GET['id'];
				$query 	= "SELECT * FROM akun WHERE id='$id'";
                $sql 	= mysqli_query($conn,$query);
				while ($hasil=mysqli_fetch_array($sql)) {				
				?>
				<form id="demo-form2" method="post" class="form-horizontal form-label-left" action="proses/update-akun" enctype="multipart/form-data">
					<input type="hidden" name="id" value="<?php echo $hasil['id']; ?>">
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Full Name <span class="required">*</span>
						</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<input name="fullname" value="<?php echo $hasil['fullname']; ?>" type="text" id="first-name" required="required" class="form-control has-feedback-right col-md-7 col-xs-12" data-parsley-id="8466">
							<span class="fa fa-font form-control-feedback right" aria-hidden="true"></span>
							<ul class="parsley-errors-list" id="parsley-id-8466"></ul>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Phone <span class="required">*</span>
						</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<input name="phone" value="<?php echo $hasil['phone']; ?>" type="text" id="last-name" name="last-name" required="required" class="form-control has-feedback-right col-md-7 col-xs-12" data-parsley-id="8182">
							<span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
							<ul class="parsley-errors-list" id="parsley-id-8182"></ul>
						</div>
					</div>
					<div class="form-group">
						<label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Email <span class="required">*</span>
						</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<input name="email" value="<?php echo $hasil['email']; ?>" id="middle-name" class="form-control has-feedback-right col-md-7 col-xs-12" type="email" name="middle-name" data-parsley-id="4638">
							<span class="fa fa-envelope form-control-feedback right" aria-hidden="true"></span>
							<ul class="parsley-errors-list" id="parsley-id-4638"></ul>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Gender</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<div id="gender" class="btn-group" data-toggle="buttons">
							<label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
								<input name="gender" value="<?php echo $hasil['gender']; ?>" type="radio" name="gender" value="male" data-parsley-multiple="gender" data-parsley-id="1051"> &nbsp; Male &nbsp;
							</label>
								<ul class="parsley-errors-list" id="parsley-id-multiple-gender"></ul>
							<label class="btn btn-primary active" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
								<input name="gender" value="<?php echo $hasil['gender']; ?>" type="radio" name="gender" value="female" checked="" data-parsley-multiple="gender" data-parsley-id="1051"> Female
							</label>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Date Of Birth <span class="required">*</span>
						</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<input name="dateofbirth" value="<?php echo $hasil['dateofbirth']; ?>" id="birthday" class="date-picker form-control col-md-7 col-xs-12" required="required" type="date">
							<ul class="parsley-errors-list" id="parsley-id-8071"></ul>
						</div>
					</div>
					<div class="form-group">
						<label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Username</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<input name="username" value="<?php echo $hasil['username']; ?>" id="middle-name" class="form-control has-feedback-right col-md-7 col-xs-12" type="text" name="middle-name" data-parsley-id="4638">
							<span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
							<ul class="parsley-errors-list" id="parsley-id-4638"></ul>
						</div>
					</div>
					<div class="form-group">
						<label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Password</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<input name="password" value="<?php echo $hasil['password']; ?>" id="middle-name" class="form-control has-feedback-right col-md-7 col-xs-12" type="password" name="middle-name" data-parsley-id="4638">
							<span class="fa fa-lock form-control-feedback right" aria-hidden="true"></span>
							<ul class="parsley-errors-list" id="parsley-id-4638"></ul>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Gambar <span class="required">*</span>
						</label>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<img src="admin/<?php echo $hasil['image']; ?>" class="img-thumbnail" class="col-lg-12" /><br>
							<input type="checkbox" name="ubah_image" value="true"> Ceklis jika ingin mengubah foto
							<input name="image" value="<?php echo $image; ?>" type="file" class="text-center dropzone col-md-12 col-xs-12">
						</div>
					</div>
					<div class="ln_solid"></div>
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
							<button type="reset" class="btn btn-danger"><i class="fa fa-refresh"></i> Reset</button>
                            <button type="submit" class="btn btn-success"><i class="fa fa-send"></i> Submit</button>
						</div>
					</div>
				</form>
				<?php } ?>
			</div>
		</div>
	</div>
<?php
	include('layout/footer.php');
?>