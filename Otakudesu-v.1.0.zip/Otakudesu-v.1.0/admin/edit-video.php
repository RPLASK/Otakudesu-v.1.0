<?php
	include('layout/head.php');
	include('layout/sidebar.php');
	include('layout/navbar.php');
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_title">
					<h2>Edit Video</h2>
					<div class="pull-right">
                        <div class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
							<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
							<script type='text/javascript'>
							<!--
							  var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
							  var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
							  var date = new Date();
							  var day = date.getDate();
							  var month = date.getMonth();
							  var thisDay = date.getDay(),thisDay = myDays[thisDay];
							  var yy = date.getYear();
							  var year = (yy < 1000) ? yy + 1900 : yy;
							  document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
							-->
							</script>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<?php 
				include "koneksi.php";
				$id = $_GET['id'];
				$query 	= "SELECT * FROM video WHERE id='$id'";
                $sql 	= mysqli_query($conn,$query);
				$hasil=mysqli_fetch_array($sql)				
				?>
				<form id="demo-form2" method="post" class="form-horizontal form-label-left" action="proses/update-video" enctype="multipart/form-data">
				<input type="hidden" name="id" value="<?php echo $hasil['id']; ?>">
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Link <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<input name="link" class="form-control" required="required" value="<?php echo $hasil['link']; ?>">
						</div>
					</div>
					<div class="ln_solid"></div>
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
							<button type="reset" class="btn btn-danger"><i class="fa fa-refresh"></i> Reset</button>
							<button type="submit" class="btn btn-success"><i class="fa fa-send"></i> Submit</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php
	include('layout/footer.php');
?>