<?php
	include('layout/head.php');
	include('layout/sidebar.php');
	include('layout/navbar.php');
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="row top_tiles">
		<div class="x_panel">
			<div class="x_title">
				<h2>Dashboard</h2>
				<div class="pull-right">
					<div class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
						<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
						<script type='text/javascript'>
							<!--
							  var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
							  var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
							  var date = new Date();
							  var day = date.getDate();
							  var month = date.getMonth();
							  var thisDay = date.getDay(),thisDay = myDays[thisDay];
							  var yy = date.getYear();
							  var year = (yy < 1000) ? yy + 1900 : yy;
							  document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
							-->
						</script>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		<div class="row">
			<div class="col-lg-3 col-xs-12">
				<div class="panel panel-primary" style="border-color: #2A3F54;">
					<div class="panel-heading" style="background: #2A3F54; border-color: #2A3F54;">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-book fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 35px;">
								<?php
								include "koneksi.php";
								$artikel = mysqli_num_rows(mysqli_query($conn, "SELECT * From artikel"));
								echo $artikel;
								?>
								</div>
								<div>Jumlah Artikel!</div>
							</div>
						</div>
					</div>
					<a href="list-artikel">
						<div class="panel-footer">
							<span class="pull-left">View Details</span>
							<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
							<div class="clearfix"></div>
						</div>
					</a>
				</div>
			</div>
			<div class="col-lg-3 col-xs-12">
				<div class="panel panel-primary" style="border-color: #2A3F54;">
					<div class="panel-heading" style="background: #2A3F54; border-color: #2A3F54;">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-group fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 35px;">
								<?php
								include "koneksi.php";
								$akun = mysqli_num_rows(mysqli_query($conn, "SELECT * From akun"));
								echo $akun;
								?>
								</div>
								<div>Jumlah Akun!</div>
							</div>
						</div>
					</div>
					<a href="list-akun">
						<div class="panel-footer">
							<span class="pull-left">View Details</span>
							<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
							<div class="clearfix"></div>
						</div>
					</a>
				</div>
			</div>
			<div class="col-lg-3 col-xs-12">
				<div class="panel panel-primary" style="border-color: #2A3F54;">
					<div class="panel-heading" style="background: #2A3F54; border-color: #2A3F54;">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-star fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 35px;">
								<?php
								include "koneksi.php";
								$rekomend = mysqli_num_rows(mysqli_query($conn, "SELECT * From rekomend"));
								echo $rekomend;
								?>
								</div>
								<div>Jumlah Rekomend!</div>
							</div>
						</div>
					</div>
					<a href="list-rekomendasi">
						<div class="panel-footer">
							<span class="pull-left">View Details</span>
							<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
							<div class="clearfix"></div>
						</div>
					</a>
				</div>
			</div>
			<div class="col-lg-3 col-xs-12">
				<div class="panel panel-primary" style="border-color: #2A3F54;">
					<div class="panel-heading" style="background: #2A3F54; border-color: #2A3F54;">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-desktop fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 35px;">
								<?php
								include "koneksi.php";
								$about = mysqli_num_rows(mysqli_query($conn, "SELECT * From partner"));
								echo $about;
								?>
								</div>
								<div>Jumlah Partner!</div>
							</div>
						</div>
					</div>
					<a href="list-partner">
						<div class="panel-footer">
							<span class="pull-left">View Details</span>
							<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
							<div class="clearfix"></div>
						</div>
					</a>
				</div>
			</div>
		</div>                               
		</div>                               
	</div>
	
<?php
	include('layout/footer.php');
?>