<?php
	include('layout/head.php');
	include('layout/sidebar.php');
	include('layout/navbar.php');
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_title">
					<h2>Add Artikel</h2>
					<div class="pull-right">
                        <div class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
							<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
							<script type='text/javascript'>
							<!--
							  var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
							  var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
							  var date = new Date();
							  var day = date.getDate();
							  var month = date.getMonth();
							  var thisDay = date.getDay(),thisDay = myDays[thisDay];
							  var yy = date.getYear();
							  var year = (yy < 1000) ? yy + 1900 : yy;
							  document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
							-->
							</script>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<form id="demo-form2" method="post" class="form-horizontal form-label-left" action="proses/save-artikel" enctype="multipart/form-data">
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Judul <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<input name="judul" type="text" class="form-control col-md-7 col-xs-12" required="required">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Isi <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<textarea name="isi" id="ckeditor" class="ckeditor" required="required"></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Penulis <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<input name="penulis" type="text" class="form-control col-md-7 col-xs-12" required="required">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Tanggal <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<input name="tanggal" type="date" class="form-control col-md-7 col-xs-12" required="required">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Hari <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<select name="hari" class="form-control">
							<?php
							include "koneksi.php";
							$query = mysqli_query($conn,"select * from hari");
							while ($data=mysqli_fetch_array($query)) {
							?>
                            	<option value="<?php echo $data['nama_hari']; ?>"><?php echo $data['nama_hari']; ?></option>
                            <?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Kategori <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<select name="kategori" class="form-control">
							<?php
							include "koneksi.php";
							$query = mysqli_query($conn,"select * from kategori");
							while ($data=mysqli_fetch_array($query)) {
							?>
                            	<option value="<?php echo $data['nama_kategori']; ?>"><?php echo $data['nama_kategori']; ?></option>
                            <?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-3 col-sm-3 col-xs-12">Gambar <i class="fa fa-star-o"></i></label>
						<div class="col-md-7 col-sm-7 col-xs-12">
							<input name="image" type="file" class="text-center dropzone col-lg-12 col-md-7 col-xs-12">
						</div>
					</div>
					<div class="ln_solid"></div>
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
							<button type="reset" class="btn btn-danger"><i class="fa fa-refresh"></i> Reset</button>
							<button type="submit" class="btn btn-success"><i class="fa fa-send"></i> Submit</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php
	include('layout/footer.php');
?>