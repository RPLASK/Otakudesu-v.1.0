<?php
session_start();

//cek apakah user sudah login
if(!isset($_SESSION['username'])){
    die("<script>alert('Anda Belum Login!');document.location.href='../login.php'</script>");//
}

?>